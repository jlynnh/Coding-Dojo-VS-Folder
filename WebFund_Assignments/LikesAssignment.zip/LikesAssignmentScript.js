var count = 9;
var countElement = document.querySelector ("#count");

console.log (countElement)

function add(){
    count++; 
    countElement.innerText = count + " like(s)";
    console.log (count)
}

var count = 12;
var countElement = document.querySelector ("#countnichole");

console.log (countElement)

function addnichole(){
    count++; 
    countElement.innerText = count + " like(s)";
    console.log (count)
}

var count = 9;
var countElement = document.querySelector ("#countjim");

console.log (countElement)

function addjim(){
    count++; 
    countElement.innerText = count + " like(s)";
    console.log (count)
}